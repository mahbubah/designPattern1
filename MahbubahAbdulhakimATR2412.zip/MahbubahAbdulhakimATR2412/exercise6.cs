using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exercise6 
{
        public interface Shape
        {
        void area();
        }


        public class Square : Shape
        {
            public void area()
            {
            Console.WriteLine("Calculating area of Square");
            Console.Write("Enter the length : ");
            float side = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of square" +(side*side));
            }
        }


        public class circle : Shape
        {
            public void area()
            {
            Console.WriteLine("Calculating area of CIRCLE");
            Console.Write("Enter the radius : ");
            float radius = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of Circle" + (3.12) * radius * radius);
            }
        }
        

        class program
        {
            static void Main(string[] args)
            {
            Console.WriteLine("Calculating area of Square");
            Shape[] shape = new Shape[2];
            shape[0] = new circle();
            shape[1] = new Square();
                for (int i = 0; i < shape.Length; i++)
                {
                shape[i].area();
                Console.ReadLine();
                }
            }
        }
}