using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Text;  
  
namespace exercise2  
{  
    class shape   
   {  
        public void Area(int side)  
         {  
            int squarearea = side * side;  
            Console.WriteLine("The Area of Square is :" + squarearea);  
         }  
        public void Area(int length, int width)  
         {  
  
            int rectarea = length * width;  
            Console.WriteLine("The Area of Rectangle is :" + rectarea);       
         }  
  
        public void Area(double radius)  
        {  
            double circlearea = 3.14 * radius * radius;  
            Console.WriteLine("The Area of Circle is :" + circlearea);  
        }    
      
    }  
  
    class Program  
    {  
        static void Main(string[] args)  
        {  
  
            shape Shape = new shape();  
            Shape.Area(8);  
            Shape.Area(5, 10);  
            Shape.Area(12.2);  
            Console.ReadKey();  
  
        }  
    }  
}  