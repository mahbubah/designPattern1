using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace exercise5
{
    class Program
    {
        public delegate int calculator(int x, int y);
 
        static int Add(int a, int b)
        {
            return a + b;
        }
        static int Sub(int a, int b)
        {
            return a - b;
        }
        static void Main(string[] args)
        {
            calculator c = new calculator(Program.Add);
            Console.WriteLine("Addition of 5 and 10 is : {0}", c(5, 10));
 
            calculator d = new calculator(Program.Sub);
            Console.WriteLine("Subtraction of 5 and 10 is : {0}", d(5, 10));
 
            Console.ReadKey();
        }
    }
}