using System;

class exercise_1
{
	static void Main(string[] args)
	{
		int SUM	= 0;
		int X	= 0;
		int Y	= 0;

		X = Convert.ToInt32(args[0]);
		Y = Convert.ToInt32(args[1]);

		SUM = X + Y;

		Console.WriteLine("Sum is: "+SUM);
		
	}
}